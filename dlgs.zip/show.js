//window.external
var we = window.external;
var iid;
var top, wndh, scrh;

function Ver(version) {
    var pos = version.lastIndexOf(".");
    if (pos == -1)
        return version;
    return version.substr(0, pos);
}

function Size(size) {
    var mb = Number(size);
    mb /= 1024;
    mb /= 1024;
    return mb.toFixed(1);
}

function Init() {
    ResizePopup();

    we.WndLeft = we.ScrWidth - we.WndWidth;

    try {
        var ver = we.GetParam("version");
        $("#ver")[0].innerText = Ver(ver);
        var ver = we.GetParam("byte_size");
        $("#size")[0].innerText = Size(ver);
    }
    catch (e) {
    }

    top = we.ScrHeight;
    wndh = we.WndHeight;
    scrh = we.ScrHeight;
    iid = setInterval(Move, 25);
}

function OnOk() {
    we.OnOk();
}

function OnCancel() {
    we.OnCancel();
}

function OnClose() {
    we.OnClose();
}

function OnDownload(lang) {
    we.OpenHref("http://punto.yandex.ru/win/release");
}

function Move() {
    if (top + wndh >= scrh + 4) {
        top -= 4;
        we.WndTop = top;
    }
    else {
        clearInterval(iid);
        we.WndTop = we.ScrHeight - we.WndHeight;
    }
}

function ResizePopup() {
    if ($(document).width() > we.ClientWidth)
        we.ClientWidth = $(document).width();

    var border_width = 2;
    var h = $("#wr").height() + border_width;
    if (we.ClientHeight != h)
        we.ClientHeight = h;
}
